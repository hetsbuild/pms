<?php

require '../../includes/auth.php';
require '../../includes/flash_message.php';
require_once '../../config/db.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {

    $id = (int)$_POST['id'];
    $category_name = trim($_POST['category_name']);

    if (empty($category_name)) {

        setMessage("Category name is required.");

        header("Location: edit.php?id=".$id);
        exit;
    }

    $stmt = $mysqli->prepare(
        "UPDATE categories
         SET category_name = ?
         WHERE id = ?"
    );

    $stmt->bind_param(
        "si",
        $category_name,
        $id
    );

    if ($stmt->execute()) {

        setMessage("Category updated successfully!");

        header("Location: index.php");
        exit;
    }

    setMessage("Failed to update category.");

    header("Location: index.php");
    exit;
}
?>