<?php

require '../../includes/auth.php';
require '../../config/db.php';

if (!isset($_GET['id'])) {

    echo "Invalid ID";
    exit;

}

$id = (int)$_GET['id'];

$stmt = $mysqli->prepare("
    DELETE FROM categories
    WHERE id = ?
");

$stmt->bind_param("i", $id);

if ($stmt->execute()) {

    echo "success";

} else {

    echo "error";

}

$stmt->close();
$mysqli->close();

exit;
?>