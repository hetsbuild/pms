<?php

require '../../config/db.php';
include '../../includes/header.php'; 


$id = $_GET['id'];

$sql = "SELECT * FROM categories WHERE id = $id";
$result = $mysqli->query($sql);

$category = $result->fetch_assoc();

?>

<!DOCTYPE html>
<html>

<head>
    <title>Edit Category</title>
    <link rel="stylesheet" href="/pms/assets/css/style.css">
</head>

<body>
    <?php include '../../includes/sidebar.php'; ?>
    <div class="main-content">

        <h2>Edit Category</h2>

        <form action="update.php" method="POST">

            <input type="hidden" name="id"
                value="<?php echo $category['id']; ?>">

            <label>Category Name : </label>

            <input type="text"
                name="category_name"
                value="<?php echo $category['category_name']; ?>">

            <button type="submit">
                Update
            </button>

        </form>

</body>

</html>