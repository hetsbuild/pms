<?php

require '../../includes/auth.php';
require '../../includes/flash_message.php';
require_once '../../config/db.php';
include '../../includes/header.php'; 


if(isset($_POST['submit'])){

    $category_name = trim($_POST['category_name']);

    if(empty($category_name)){

        setMessage("Category name is required.");

        header("Location: add_categories.php");
        exit;
    }

    $stmt = $mysqli->prepare(
        "INSERT INTO categories (category_name)
         VALUES (?)"
    );

    $stmt->bind_param("s", $category_name);

    if($stmt->execute()){

        setMessage("Category added successfully!");

        header("Location: index.php");
        exit;
    }

    setMessage("Failed to add category.");

    header("Location: add_categories.php");
    exit;
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Add Category</title>
    <link rel="stylesheet" href="/pms/assets/css/style.css">
</head>
<body>
<?php include '../../includes/sidebar.php'; ?>
<div class="main-content">

<h2>Add Category</h2>
<?php showMessages(); ?>

<form method="POST"> 
    <label>Category Name</label>
    <input type="text" name="category_name" placeholder="Enter Category Name" required>

    <button type="submit" name="submit">
        Add Category
    </button>
</form>

</body>
</html>