<?php

require "../../includes/auth.php";
require_once "../../config/db.php";
require "../../includes/flash_message.php";
include '../../includes/header.php'; 



if (isset($_POST['submit'])) {
    $name = trim($_POST['name']);
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT);
    $role = trim($_POST['role']);
    $status = (int)$_POST['status'];

    if (!empty($name) && !empty($password)) {
        $stmt = $mysqli->prepare(
            "insert into users (name, password, role, status) 
            values(?,?,?,?) "
        );
        $stmt->bind_param("sssi", $name, $password, $role, $status);

        if ($stmt->execute()) {
            setMessage("User added successfully!");
            header("Location: index.php");
            exit;
        } else {
            setMessage("Failed to add user.");
            header("Location: add.php");
            exit;
        }
        $stmt->close();
    } else {
        setMessage("All fields are required.");
        header("Location: add.php");
        exit;
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add User</title>
    <link rel="stylesheet" href="/pms/assets/css/style.css">
</head>

<body>
<?php include '../../includes/sidebar.php'; ?>
<div class="main-content">

    <h2>Add User</h2>
    <?php showMessages(); ?>

    <?php if (isset($error)) { ?>
        <p style="color:red;">
            <?php echo $error; ?>
        </p>
    <?php } ?>

    <form method="post">
        <label>Userame</label>
        <input type="text" name="name" required><br><br>

        <label>Password</label>
        <input type="password" name="password" required><br><br>

        <label>Role</label>
        <select name="role">
            <option value="admin">
                Admin
            </option>
            <option value="staff">
                Staff
            </option>
        </select>
        <br><br>

        <label>Status</label><br>
        <select name="status">
            <option value="1">
                Active
            </option>

            <option value="0">
                Inactive
            </option>
        </select>
        <br><br>

        <button type="submit" name="submit">Add User</button>
    </form>
</body>

</html>