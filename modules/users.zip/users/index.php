<?php
require '../../includes/auth.php';
require_once '../../config/db.php';
require "../../includes/flash_message.php";
require '../../includes/permission.php';
include '../../includes/header.php'; 

?>


<!DOCTYPE html>
<html>

<head>
    <title>Users</title>
    <link rel="stylesheet" href="/pms/assets/css/style.css">
</head>

<body>

    <?php include '../../includes/sidebar.php'; ?>

    <div class="main-content">

        <h2>Users</h2>

        <?php showMessages(); ?>

        <a href="add.php">Add User</a>

        <br><br>

        <input
            type="text"
            id="search"
            placeholder="Search User Name">

        <select id="sort">
            <option value="newest">Newest First</option>
            <option value="az">Name (A-Z)</option>
            <option value="za">Name (Z-A)</option>
        </select>

        <br><br>
        <div id="message"></div>
        <div id="user-data"></div>

    </div>

    <script>
        function loadUsers(page = 1) {

            let search =
                document.getElementById("search").value;

            let sort =
                document.getElementById("sort").value;

            let xhr = new XMLHttpRequest();

            xhr.open(
                "GET",
                "ajax.php?search=" +
                encodeURIComponent(search) +
                "&sort=" +
                encodeURIComponent(sort) +
                "&page=" +
                page,
                true
            );

            xhr.onload = function() {

                if (xhr.status == 200) {

                    document.getElementById("user-data")
                        .innerHTML = xhr.responseText;

                }

            };

            xhr.send();
        }

        document.addEventListener("DOMContentLoaded", function() {

            loadUsers();

            document.getElementById("search")
                .addEventListener("keyup", function() {

                    loadUsers();

                });

            document.getElementById("sort")
                .addEventListener("change", function() {

                    loadUsers();

                });

            document.addEventListener("click", function(e) {

                if (e.target.classList.contains("pagination-link")) {

                    e.preventDefault();

                    let page =
                        e.target.dataset.page;

                    loadUsers(page);

                }

            });

        });

        function toggleStatus(id) {

            fetch("../../ajax/toggle_status.php", {

                    method: "POST",

                    headers: {
                        "Content-Type": "application/x-www-form-urlencoded"
                    },

                    body: "id=" + id + "&table=users"

                })

                .then(response => response.text())

                .then(data => {

                    console.log(data);

                    loadUsers();

                })

                .catch(error => {

                    console.error(error);

                });

        }

       function deleteUser(id) {

            if (!confirm('Delete this product?')) {
                return;
            }

            fetch('delete.php?id=' + id)

                .then(response => response.text())

                .then(() => {

                    loadUsers();

                });
        }
    </script>   

</body>

</html>