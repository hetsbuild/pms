<?php
require "../../config/db.php";
include '../../includes/header.php'; 

$id = $_GET['id'];

$sql = "select * from users where id = $id ";
$result = $mysqli->query($sql);

$user = $result->fetch_assoc();
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit User</title>
    <link rel="stylesheet" href="/pms/assets/css/style.css">
</head>

<body>
    <?php include '../../includes/sidebar.php'; ?>
    <div class="main-content">

        <h2>Edit User</h2>
        <form action="update.php" method="post">

            <input type="hidden" name="id" value="<?php echo $user['id']; ?>">

            <label>Name</label>
            <input type="text" name="name" value="<?php echo $user['name']; ?>">
            <br><br>

            <label>Role</label>
            <select name="role">
                <option value="admin"
                    <?php if ($user['role'] == 'admin') echo 'selected'; ?>>
                    Admin
                </option>
                <option value="staff">
                    <?php if ($user['role'] == 'staff') echo 'selected'; ?>
                    Staff
                </option>
            </select>
            <br><br>

            <label>Status</label><br>
            <select name="status">
                <option value="1"
                    <?php if ($user['status'] == '1') echo 'selected'; ?>>
                    Active
                </option>

                <option value="0"
                    <?php if ($user['status'] == '0') echo 'selected'; ?>>
                    Inactive
                </option>
            </select>
            <br><br>

            <button type="submit" name="submit ">Update User</button>
        </form>
</body>

</html>