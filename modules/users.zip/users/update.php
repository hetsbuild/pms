<?php

require '../../includes/auth.php';
require '../../includes/flash_message.php';
require_once '../../config/db.php';

$id = $_POST['id'];
$name = $_POST['name'];
$role = $_POST['role'];
$status = $_POST['status'];


$sql = "update users set
    name = '$name',
    role = '$role',
    status = '$status'
    where id = '$id'";

$mysqli->query($sql);

header("Location: index.php");
?>