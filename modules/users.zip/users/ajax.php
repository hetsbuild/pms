<?php

require '../../config/db.php';

$search = isset($_GET['search'])
    ? trim($_GET['search'])
    : '';

$sort = isset($_GET['sort'])
    ? $_GET['sort']
    : 'newest';

$page = isset($_GET['page'])
    ? (int)$_GET['page']
    : 1;

if ($page < 1) {
    $page = 1;
}

$records_per_page = 5;
$offset = ($page - 1) * $records_per_page;

switch ($sort) {

    case 'az':
        $order_by = "name ASC";
        break;

    case 'za':
        $order_by = "name DESC";
        break;

    default:
        $order_by = "id DESC";
}

$count_sql = "
SELECT COUNT(*) as total
FROM users
WHERE name LIKE '%$search%'
";

$count_result = $mysqli->query($count_sql);
$total_records = $count_result->fetch_assoc()['total'];

$total_pages = ceil($total_records / $records_per_page);

$sql = "
SELECT *
FROM users
WHERE (name LIKE '%$search%'
OR role LIKE '%$search%')
ORDER BY $order_by
LIMIT $records_per_page OFFSET $offset
";

$result = $mysqli->query($sql);
?>

<table border="2" cellpadding="10" cellspacing="1">

    <tr>
        <th>ID</th>
        <th>Name</th>
        <th>Role</th>
        <th>Status</th>
        <th>Action</th>
    </tr>

    <?php while ($row = $result->fetch_assoc()) { ?>

        <tr>

            <td><?php echo $row['id']; ?></td>

            <td><?php echo htmlspecialchars($row['name']); ?></td>

            <td><?php echo htmlspecialchars($row['role']); ?></td>

            <td>
                <input
                    type="checkbox"
                    <?php echo ($row['status'] == 1) ? 'checked' : ''; ?>
                    onchange="toggleStatus(<?php echo $row['id']; ?>)">

                <?php echo ($row['status'] == 1) ? 'Active' : 'Inactive'; ?>
            </td>

            <td>

                <a href="edit.php?id=<?php echo $row['id']; ?>">
                    Edit
                </a>

                /

                <button onclick="deleteUser(<?= $row['id'] ?>)">
                    Delete
                </button>

            </td>

        </tr>

    <?php } ?>

</table>

<br>

<?php if ($total_pages > 1) { ?>

<div style="margin-top:20px;">

    <?php for ($i = 1; $i <= $total_pages; $i++) { ?>

        <button
            class="pagination-link"
            data-page="<?php echo $i; ?>"
            <?php if ($i == $page) ?>>

            <?php echo $i; ?>

        </button>

    <?php } ?>

</div>

<?php } ?>