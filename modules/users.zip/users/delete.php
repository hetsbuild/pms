<?php

require '../../includes/auth.php';
require_once '../../config/db.php';
require "../../includes/flash_message.php";

if (!isset($_GET['id'])) {
    header("Location: index.php");
    exit;
}

$id = (int) $_GET['id'];

    $stmt = $mysqli->prepare("DELETE FROM users WHERE id = ?");
$stmt->bind_param("i", $id);

if ($stmt->execute()) {

    echo "success";

} else {

    echo "error";

}

$stmt->close();
exit;
?>