<?php

session_start();
require '../config/db.php';

// Check product ID
if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    header("Location: index.php");
    exit;
}

$product_id = (int) $_GET['id'];

// Check customer login
if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'customer') {

    // Save product id so we can buy it after login
    $_SESSION['buy_product_id'] = $product_id;

    header("Location: login.php");
    exit;
}

$user_id = $_SESSION['user_id'];

// Check if already purchased (optional)
$stmt = $mysqli->prepare("
    SELECT id
    FROM purchases
    WHERE user_id = ? AND product_id = ?
");


// multiple time purchase product block

// $stmt->bind_param("ii", $user_id, $product_id);
// $stmt->execute();
// $result = $stmt->get_result();

// if ($result->num_rows > 0) {

//     echo "<script>
//         alert('You have already purchased this product.');
//         window.location='dashboard.php';
//     </script>";
//     exit;
// }


// Insert purchase
$stmt = $mysqli->prepare("
    INSERT INTO purchases(user_id, product_id)
    VALUES(?, ?)
");

$stmt->bind_param("ii", $user_id, $product_id);
$stmt->execute();

echo "<script>
    alert('Product purchased successfully.');
    window.location='purchases.php';
</script>";

?>