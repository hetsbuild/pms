<?php

require "../../includes/auth.php";
require "../../includes/flash_message.php";
require_once "../../config/db.php";

if (isset($_GET['id'])) {

    $id = (int)$_GET['id'];

    $stmt = $mysqli->prepare(
        "DELETE FROM subcategories
         WHERE id = ?"
    );

    $stmt->bind_param("i", $id);

    if ($stmt->execute()) {

        echo "success";

    } else {

        echo "error";

    }

    $stmt->close();
    $mysqli->close();

    exit;
}