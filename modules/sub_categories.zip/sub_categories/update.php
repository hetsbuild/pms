<?php

require "../../includes/auth.php";
require "../../includes/flash_message.php";
require_once "../../config/db.php";

if($_SERVER['REQUEST_METHOD'] == 'POST'){

    $id = (int)$_POST['id'];

    $subcategory_name =
        trim($_POST['subcategory_name']);

    if(empty($subcategory_name)){

        setMessage("Sub Category name is required.");

        header("Location: edit.php?id=".$id);
        exit;
    }

    $stmt = $mysqli->prepare(
        "UPDATE subcategories
         SET subcategory_name = ?
         WHERE id = ?"
    );

    $stmt->bind_param(
        "si",
        $subcategory_name,
        $id
    );

    if($stmt->execute()){

        setMessage(
            "Sub Category updated successfully!"
        );

        header("Location: index.php");
        exit;
    }

    setMessage("Failed to update sub category.");

    header("Location: index.php");
    exit;
}
?>