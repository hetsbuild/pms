<?php
require "../../includes/auth.php";
include '../../includes/header.php';
require_once "../../config/db.php";

$id = $_GET['id'];
$sql = "select * from subcategories where id = $id ";
$result = $mysqli->query($sql);

$subcategories = $result->fetch_assoc();

$categorySql = "SELECT * FROM categories";
$categories = $mysqli->query($categorySql);
?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Sub categories</title>
    <link rel="stylesheet" href="/pms/assets/css/style.css">
</head>

<body>
    <?php include '../../includes/sidebar.php'; ?>
    <div class="main-content">

        <h2>Edit Sub-categories</h2>

        <form action="update.php" method="post">
            <input type="hidden" name="id" value="<?php echo $subcategories['id'];     ?>">
            <label>Parent Category :</label>

            <select name="category_id">
                <?php while ($category = $categories->fetch_assoc()) { ?>
                    <option
                        value="<?= $category['id']; ?>"
                        <?= ($category['id'] == $subcategories['category_id']) ? 'selected' : ''; ?>>
                        <?= htmlspecialchars($category['category_name']); ?>
                    </option>
                <?php } ?>
            </select>

            <br><br>
            <label>Subcategories Name : </label>
            <input type="text" name="subcategory_name" value="<?php echo  $subcategories['subcategory_name']; ?>">

            <button type="submit" value="submit">Update</button>
        </form>
</body>

</html>