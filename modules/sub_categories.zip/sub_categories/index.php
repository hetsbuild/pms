<?php
require '../../includes/auth.php';
require_once '../../config/db.php';
require "../../includes/flash_message.php";
require '../../includes/permission.php';
include '../../includes/header.php'; 

?>

<!DOCTYPE html>
<html>

<head>
    <title>Sub Categories</title>
    <link rel="stylesheet" href="/pms/assets/css/style.css">
</head>

<body>

    <?php include '../../includes/sidebar.php'; ?>

    <div class="main-content">

        <h2>Sub Categories</h2>

        <?php showMessages(); ?>
        <?php if (isAdmin()) { ?>
            <a href="add_subcategories.php">Add Sub Category</a>
        <?php } ?>
        <br><br>

        <input type="text"
            id="search"
            placeholder="Search Category or Sub Category">

        <select id="sort">
            <option value="newest">Newest First</option>
            <option value="az">Name (A-Z)</option>
            <option value="za">Name (Z-A)</option>
        </select>

        <br><br>

        <div id="subcategory-data"></div>

    </div>


    <script>
        function loadSubCategories(page = 1) {

            let search =
                document.getElementById("search").value;

            let sort =
                document.getElementById("sort").value;

            let xhr = new XMLHttpRequest();

            xhr.open(
                "GET",
                "ajax.php?search=" +
                encodeURIComponent(search) +
                "&sort=" +
                encodeURIComponent(sort) +
                "&page=" +
                page,
                true
            );

            xhr.onload = function() {

                if (xhr.status == 200) {

                    document.getElementById("subcategory-data")
                        .innerHTML = xhr.responseText;

                }

            };

            xhr.send();
        }

        document.addEventListener("DOMContentLoaded", function() {

            loadSubCategories();

            document.getElementById("search")
                .addEventListener("keyup", function() {

                    loadSubCategories();

                });

            document.getElementById("sort")
                .addEventListener("change", function() {

                    loadSubCategories();

                });

            document.addEventListener("click", function(e) {

                if (e.target.classList.contains("pagination-link")) {

                    e.preventDefault();

                    let page =
                        e.target.dataset.page;

                    loadSubCategories(page);

                }

            });

        });

        function toggleStatus(id) {

            fetch("../../ajax/toggle_status.php", {

                    method: "POST",

                    headers: {
                        "Content-Type": "application/x-www-form-urlencoded"
                    },

                    body: "id=" + id + "&table=subcategories"

                })

                .then(response => response.text())

                .then(data => {

                    console.log(data);

                    loadSubCategories();

                })

                .catch(error => {

                    console.error(error);

                });

        }

        function deleteSubCategory(id) {

            if (!confirm('Delete this subcategory?')) {
                return;
            }

            fetch('delete.php?id=' + id)

                .then(response => response.text())

                .then(data => {

                    loadSubCategories();

                });
        }
    </script>
</body>

</html>

