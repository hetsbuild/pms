<?php
require "../../includes/auth.php";
require_once "../../config/db.php";
require "../../includes/flash_message.php"  ;   
include '../../includes/header.php'; 


$categories = $mysqli->query("SELECT * FROM categories ORDER BY category_name");

if (isset($_POST['submit'])) {

    $category_id = (int)$_POST['category_id'];
    $subcategory_name = trim($_POST['subcategory_name']);

    if (!empty($subcategory_name) && $category_id > 0) {

        $stmt = $mysqli->prepare(
            "INSERT INTO subcategories (category_id, subcategory_name)
             VALUES (?, ?)"
        );

        $stmt->bind_param("is", $category_id, $subcategory_name);

        if ($stmt->execute()) {
            setMessage("Sub Category added successfully!");
            header("Location: index.php");
            exit;
        } else {
            setMessage("Failed to add subcategory.");
            header("Location: add_subcategories.php");
            exit;
        }

        $stmt->close();
    } else {
        setMessage("All fields are required.");
        header("Location: add_subcategories.php");
        exit;
    }
}
?>

<!DOCTYPE html>
<html>

<head>
    <title>Add Sub Category</title>
    <link rel="stylesheet" href="/pms/assets/css/style.css">
</head>

<body>

<?php include '../../includes/sidebar.php'; ?>
<div class="main-content">


    <h2>Add Sub Category</h2>
    <?php showMessages(); ?>

    <?php if (isset($error)) { ?>
        <p style="color:red;">
            <?php echo $error; ?>
        </p>
    <?php } ?>

    <form method="POST">

        <label>Category</label><br>

        <select name="category_id" required>
            <option value="">Select Category</option>

            <?php while ($cat = $categories->fetch_assoc()) { ?>
                <option value="<?php echo $cat['id']; ?>">
                    <?php echo htmlspecialchars($cat['category_name']); ?>
                </option>
            <?php } ?>

        </select>

        <br><br>

        <label>Sub Category Name</label><br>

        <input
            type="text"
            name="subcategory_name"
            placeholder="Enter Sub-Category"
            required>

        <br><br>

        <button type="submit" name="submit">
            Add Sub Category
        </button>

    </form>

</body>

</html>