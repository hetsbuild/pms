<?php

require '../../config/db.php';
require_once '../../includes/auth.php';
require '../../includes/permission.php';

$search = isset($_GET['search'])
    ? trim($_GET['search'])
    : '';

$sort = isset($_GET['sort'])
    ? $_GET['sort']
    : 'newest';

$page = isset($_GET['page'])
    ? (int)$_GET['page']
    : 1;

if ($page < 1) {
    $page = 1;
}

$records_per_page = 5;
$offset = ($page - 1) * $records_per_page;

switch ($sort) {

    case 'az':
        $order_by = "s.subcategory_name ASC";
        break;

    case 'za':
        $order_by = "s.subcategory_name DESC";
        break;

    default:
        $order_by = "s.id DESC";
}

$count_sql = "
SELECT COUNT(*) as total
FROM subcategories s
INNER JOIN categories c
ON s.category_id = c.id
WHERE
(
    s.subcategory_name LIKE '%$search%'
    OR c.category_name LIKE '%$search%'
)
";

$count_result = $mysqli->query($count_sql);
$total_records = $count_result->fetch_assoc()['total'];

$total_pages = ceil($total_records / $records_per_page);

$sql = "
SELECT
    s.*,
    c.category_name
FROM subcategories s
INNER JOIN categories c
ON s.category_id = c.id
WHERE
(
    s.subcategory_name LIKE '%$search%'
    OR c.category_name LIKE '%$search%'
)
ORDER BY $order_by
LIMIT $records_per_page OFFSET $offset
";

$result = $mysqli->query($sql);
?>


<table border="1" cellpadding="10">

    <tr>
        <th>ID</th>
        <th>Category</th>
        <th>Sub Category</th>
        <?php if (isAdmin()) { ?>
        <th>Status</th>
        <?php } ?>

        <?php if (isAdmin()) { ?>
            <th>Action</th>
        <?php } ?>
    </tr>

    <?php while ($row = $result->fetch_assoc()) { ?>

        <tr>

            <td><?php echo $row['id']; ?></td>

            <td>
                <?php echo htmlspecialchars($row['category_name']); ?>
            </td>

            <td>
                <?php echo htmlspecialchars($row['subcategory_name']); ?>
            </td>
            <?php if (isAdmin()) { ?>
                <td>
                    <input
                        type="checkbox"
                        <?php echo ($row['status'] == 1) ? 'checked' : ''; ?>
                        onchange="toggleStatus(<?php echo $row['id']; ?>)">

                    <?php echo ($row['status'] == 1) ? 'Active' : 'Inactive'; ?>
                </td>
            <?php } ?>
            <?php if (isAdmin()) { ?>
                <td>

                    <a href="edit.php?id=<?php echo $row['id']; ?>">
                        Edit
                    </a>

                    /

                    <button onclick="deleteSubCategory(<?php echo $row['id']; ?>)">
                        Delete
                    </button>

                </td>
            <?php } ?>


        </tr>

    <?php } ?>

</table>

<br>

<?php if ($total_pages > 1) { ?>

    <div style="margin-top:20px;">

        <?php for ($i = 1; $i <= $total_pages; $i++) { ?>

            <button
                class="pagination-link"
                data-page="<?php echo $i; ?>"
                <?php if ($i == $page) { ?>
                <?php } ?>>
                <?php echo $i; ?>
            </button>

        <?php } ?>

    </div>

<?php } ?>